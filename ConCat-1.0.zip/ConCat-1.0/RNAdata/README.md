ConCat
======

Alignment Concatenation Program (Under Development phase)
===========================================

This folder contains gene alignments for RNA structure prediction